jarcraft alpha 1.0.0
====================

[EN] How to run
1. Install Java 8 or newer (Oracle Java / Adoptium Temurin recommended).
2. Keep "jarcraft-alpha1.0.0.jar" and "legacy-jarcraft-launcher.exe"
   in the SAME folder.
3. Double-click "legacy-jarcraft-launcher.exe", pick memory, press Play.
   Or run directly:  java -jar jarcraft-alpha1.0.0.jar

[JP] 実行方法
1. Java 8 以降をインストールしてください（Oracle Java / Adoptium 推奨）。
2. 「jarcraft-alpha1.0.0.jar」と「legacy-jarcraft-launcher.exe」を
   同じフォルダに置いてください。
3. 「legacy-jarcraft-launcher.exe」をダブルクリックし、メモリを選んで
   Play を押してください。直接実行の場合:  java -jar jarcraft-alpha1.0.0.jar

Controls / 操作
  Mouse        : look            マウス: 視点
  WASD         : move            移動
  Space        : jump            ジャンプ
  Shift        : sneak           しゃがみ
  Left click   : break block     ブロック破壊
  Right click  : place block     ブロック設置
  1-9          : select block    ブロック選択
  F3           : debug info      デバッグ表示
  Esc          : release mouse   マウス解放

If Windows SmartScreen shows a warning for the launcher, click
"More info" -> "Run anyway" (unsigned binary).
スマートスクリーンの警告が出た場合は「詳細情報」→「実行」を選択してください。
